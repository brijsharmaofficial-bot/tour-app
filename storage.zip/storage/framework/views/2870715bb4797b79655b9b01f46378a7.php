
<?php $__env->startSection('title', $page->title); ?>

<?php $__env->startSection('content'); ?>
    <h2 class="mb-3"><?php echo e($page->title); ?></h2>
    <p><strong>Slug:</strong> <?php echo e($page->slug); ?></p>
    <p><strong>Status:</strong> <span class="badge bg-<?php echo e($page->status === 'published' ? 'success' : 'secondary'); ?>"><?php echo e(ucfirst($page->status)); ?></span></p>
    <hr>

    <div class="mb-4"><?php echo $page->content; ?></div>

    <a href="<?php echo e(route('pages.edit', $page->id)); ?>" class="btn btn-warning">Edit Page</a>
    <a href="<?php echo e(route('pages.index')); ?>" class="btn btn-secondary">Back to List</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/tour-app/resources/views/packages/roundtrip/show.blade.php ENDPATH**/ ?>
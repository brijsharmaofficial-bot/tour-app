<?php $__env->startSection('content'); ?>
<div class="container py-4">
    <h4 class="fw-bold mb-3">Edit Cab</h4>

    <form method="POST" action="<?php echo e(route('cabs.update', $cab)); ?>" class="card p-4 shadow-sm border-0" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="row g-3">
            <div class="col-md-6">
                <label class="form-label">Vendor</label>
                <select name="vendor_id" class="form-select" required>
                    <option value="">Select Vendor</option>
                    <?php $__currentLoopData = $vendors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($vendor->id); ?>" <?php echo e($vendor->id == $cab->vendor_id ? 'selected' : ''); ?>>
                            <?php echo e($vendor->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-md-6">
                <label class="form-label">Cab Name</label>
                <input type="text" name="cab_name" class="form-control" value="<?php echo e($cab->cab_name); ?>" required>
            </div>

            <div class="col-md-6">
                <label class="form-label">Cab Image</label>
                <input type="file" name="image" class="form-control">
                <?php if(isset($cab) && $cab->image): ?>
                    <div class="mt-2">
                        <img src="<?php echo e(asset('storage/'.$cab->image)); ?>" width="100" class="rounded border">
                        <p class="small text-muted mt-1">Current Image</p>
                    </div>
                <?php endif; ?>
            </div>

            <div class="col-md-6">
                <label class="form-label">Registration Number</label>
                <input type="text" name="registration_no" class="form-control" value="<?php echo e($cab->registration_no); ?>" required>
            </div>
            <div class="col-md-6">
                <label class="form-label">Cab Type</label>
                <select name="cab_type" class="form-select">
                    <option value="sedan" <?php echo e($cab->type == 'sedan' ? 'selected' : ''); ?>>Sedan</option>
                    <option value="suv" <?php echo e($cab->type == 'suv' ? 'selected' : ''); ?>>SUV</option>
                    <option value="hatchback" <?php echo e($cab->type == 'hatchback' ? 'selected' : ''); ?>>Hatchback</option>
                    <option value="tempo" <?php echo e($cab->type == 'tempo' ? 'selected' : ''); ?>>Tempo</option>
                </select>
            </div>
            <div class="col-md-6">
                <label class="form-label">Seating Capacity</label>
                <input type="number" name="capacity" class="form-control" value="<?php echo e($cab->capacity); ?>" required>
            </div>
           
            <div class="col-md-6">
                <label class="form-label">Status</label>
                <select name="status" class="form-select">
                    <option value="active" <?php echo e($cab->status == 'active' ? 'selected' : ''); ?>>Active</option>
                    <option value="inactive" <?php echo e($cab->status == 'inactive' ? 'selected' : ''); ?>>Inactive</option>
                </select>
            </div>
        </div>

        <div class="mt-4 d-flex justify-content-end">
            <button class="btn btn-success me-2">Update</button>
            <a href="<?php echo e(route('cabs.index')); ?>" class="btn btn-secondary">Cancel</a>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/tour-app/resources/views/cabs/edit.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'Booking #' . $booking->id . ' - Details'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid py-4">
    <!-- Header Section -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('bookings.index')); ?>" class="text-decoration-none">Bookings</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Booking #<?php echo e($booking->id); ?></li>
                </ol>
            </nav>
            <h4 class="fw-bold mb-1">Booking Details</h4>
            <p class="text-muted mb-0">Complete information about booking #<?php echo e($booking->id); ?></p>
        </div>
        <div class="d-flex gap-2">
            <a href="<?php echo e(route('bookings.edit', $booking)); ?>" class="btn btn-warning d-none">
                <i class="fas fa-edit me-2"></i>Edit Booking
            </a>
            <a href="<?php echo e(route('bookings.index')); ?>" class="btn btn-outline-secondary">
                <i class="fas fa-arrow-left me-2"></i>Back to List
            </a>
        </div>
    </div>

    <!-- Main Content -->
    <div class="row">
        <!-- Booking Information -->
        <div class="col-xl-8 col-lg-7">
            <!-- Trip Information Card -->
            <div class="card shadow-sm border-0 mb-4">
                <div class="card-header bg-gradient-primary text-white py-3">
                    <h5 class="card-title mb-0 d-flex align-items-center">
                        <i class="fas fa-route me-2"></i>
                        Trip Information
                    </h5>
                </div>
                <div class="card-body p-4">
                    <div class="row g-4">
                        <!-- Route Information -->
                        <div class="col-12">
                            <div class="route-display d-flex align-items-center justify-content-between p-3 bg-light rounded">
                                <div class="text-center">
                                    <div class="location-icon bg-primary text-white rounded-circle mx-auto mb-2">
                                        <i class="fas fa-map-marker-alt"></i>
                                    </div>
                                    <h6 class="fw-semibold mb-1">From</h6>
                                    <p class="mb-0"><?php echo e($booking->fromCity->name ?? 'N/A'); ?></p>
                                    <small class="text-muted"><?php echo e($booking->pickup_address); ?></small>
                                </div>
                                <div class="route-arrow mx-4">
                                    <i class="fas fa-arrow-right text-primary fs-2"></i>
                                </div>
                                <div class="text-center">
                                    <div class="location-icon bg-success text-white rounded-circle mx-auto mb-2">
                                        <i class="fas fa-flag-checkered"></i>
                                    </div>
                                    <h6 class="fw-semibold mb-1">To</h6>
                                    <p class="mb-0"><?php echo e($booking->toCity->name ?? 'N/A'); ?></p>
                                    <small class="text-muted"><?php echo e($booking->drop_address ?? 'Not specified'); ?></small>
                                </div>
                            </div>
                        </div>

                        <!-- Trip Details -->
                        <div class="col-md-6">
                            <div class="detail-card">
                                <div class="detail-icon bg-info">
                                    <i class="fas fa-calendar-day"></i>
                                </div>
                                <div class="detail-content">
                                    <label class="detail-label">Pickup Date & Time</label>
                                    <p class="detail-value">
                                        <?php echo e(\Carbon\Carbon::parse($booking->pickup_date)->format('M d, Y')); ?>

                                        at <?php echo e(\Carbon\Carbon::parse($booking->pickup_time)->format('h:i A')); ?>

                                    </p>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="detail-card">
                                <div class="detail-icon bg-warning">
                                    <i class="fas fa-box"></i>
                                </div>
                                <div class="detail-content">
                                    <label class="detail-label">Package Type</label>
                                    <p class="detail-value text-capitalize">
                                        <?php echo e($booking->package->tripType->name ?? 'N/A'); ?>

                                    </p>
                                </div>
                            </div>
                        </div>

                        <!-- Additional Trip Information -->
                        <div class="col-md-6">
                            <div class="detail-card">
                                <div class="detail-icon bg-secondary">
                                    <i class="fas fa-road"></i>
                                </div>
                                <div class="detail-content">
                                    <label class="detail-label">Estimated Distance</label>
                                    <p class="detail-value">
                                        <?php echo e($booking->estimated_distance ?? 'N/A'); ?> km
                                    </p>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="detail-card">
                                <div class="detail-icon bg-dark">
                                    <i class="fas fa-clock"></i>
                                </div>
                                <div class="detail-content">
                                    <label class="detail-label">Estimated Duration</label>
                                    <p class="detail-value">
                                        <?php echo e($booking->estimated_duration ?? 'N/A'); ?>

                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Package Details Card -->
            <div class="card shadow-sm border-0 mb-4">
                <div class="card-header bg-white py-3">
                    <h6 class="card-title mb-0">
                        <i class="fas fa-box-open me-2 text-primary"></i>
                        Package Details
                    </h6>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label text-muted">Package Type</label>
                            <p class="fw-semibold"><?php echo e($booking->package->tripType->name ?? 'N/A'); ?></p>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label text-muted">Vehicle Type</label>
                            <p class="fw-semibold"><?php echo e($booking->package->cab->name ?? 'N/A'); ?></p>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label text-muted">Base Fare</label>
                            <p class="fw-semibold">₹<?php echo e(number_format($booking->package->base_fare ?? 0, 2)); ?></p>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label text-muted">Price Per KM</label>
                            <p class="fw-semibold">₹<?php echo e(number_format($booking->package->price_per_km ?? 0, 2)); ?></p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Fare Breakdown Card -->
            <div class="card shadow-sm border-0 mb-4 d-none">
                <div class="card-header bg-white py-3">
                    <h6 class="card-title mb-0">
                        <i class="fas fa-receipt me-2 text-primary"></i>
                        Fare Breakdown
                    </h6>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6 mb-2">
                            <div class="d-flex justify-content-between">
                                <span class="text-muted">Base Fare:</span>
                                <span class="fw-semibold">₹<?php echo e(number_format($booking->base_fare ?? 0, 2)); ?></span>
                            </div>
                        </div>
                        <div class="col-md-6 mb-2">
                            <div class="d-flex justify-content-between">
                                <span class="text-muted">Distance Charges:</span>
                                <span class="fw-semibold">₹<?php echo e(number_format($booking->distance_fare ?? 0, 2)); ?></span>
                            </div>
                        </div>
                        <div class="col-md-6 mb-2">
                            <div class="d-flex justify-content-between">
                                <span class="text-muted">Waiting Charges:</span>
                                <span class="fw-semibold">₹<?php echo e(number_format($booking->waiting_charges ?? 0, 2)); ?></span>
                            </div>
                        </div>
                        <div class="col-md-6 mb-2">
                            <div class="d-flex justify-content-between">
                                <span class="text-muted">Night Charges:</span>
                                <span class="fw-semibold">₹<?php echo e(number_format($booking->night_charges ?? 0, 2)); ?></span>
                            </div>
                        </div>
                        <div class="col-md-6 mb-2">
                            <div class="d-flex justify-content-between">
                                <span class="text-muted">Toll/Parking Charges:</span>
                                <span class="fw-semibold">₹<?php echo e(number_format($booking->toll_charges ?? 0, 2)); ?></span>
                            </div>
                        </div>
                        <div class="col-md-6 mb-2">
                            <div class="d-flex justify-content-between">
                                <span class="text-muted">Other Charges:</span>
                                <span class="fw-semibold">₹<?php echo e(number_format($booking->other_charges ?? 0, 2)); ?></span>
                            </div>
                        </div>
                        <div class="col-12 mt-3 pt-3 border-top">
                            <div class="d-flex justify-content-between">
                                <span class="fw-bold">Subtotal:</span>
                                <span class="fw-bold">₹<?php echo e(number_format($booking->subtotal_fare ?? 0, 2)); ?></span>
                            </div>
                        </div>
                        <div class="col-md-6 mb-2">
                            <div class="d-flex justify-content-between">
                                <span class="text-muted">Tax (<?php echo e($booking->tax_percentage ?? 0); ?>%):</span>
                                <span class="fw-semibold">₹<?php echo e(number_format($booking->tax_amount ?? 0, 2)); ?></span>
                            </div>
                        </div>
                        <div class="col-md-6 mb-2">
                            <div class="d-flex justify-content-between">
                                <span class="text-muted">Discount:</span>
                                <span class="fw-semibold text-success">-₹<?php echo e(number_format($booking->discount_amount ?? 0, 2)); ?></span>
                            </div>
                        </div>
                        <div class="col-12 mt-3 pt-3 border-top">
                            <div class="d-flex justify-content-between">
                                <span class="fw-bold fs-5">Total Fare:</span>
                                <span class="fw-bold fs-5 text-primary">₹<?php echo e(number_format($booking->total_estimated_fare, 2)); ?></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Customer & Assignment Information -->
            <div class="row">
                <!-- Customer Information -->
                <div class="col-md-6 mb-4">
                    <div class="card shadow-sm border-0 h-100">
                        <div class="card-header bg-white py-3">
                            <h6 class="card-title mb-0">
                                <i class="fas fa-user me-2 text-primary"></i>
                                Customer Information
                            </h6>
                        </div>
                        <div class="card-body">
                            <div class="customer-info text-center">
                                <div class="customer-avatar bg-primary text-white rounded-circle mx-auto mb-3">
                                    <i class="fas fa-user fs-4"></i>
                                </div>
                                <h5 class="customer-name mb-2"><?php echo e($booking->user->name ?? 'Guest User'); ?></h5>
                                <p class="text-muted mb-3"><?php echo e($booking->user->email ?? 'N/A'); ?></p>
                                
                                <div class="contact-info">
                                    <?php if($booking->user->phone ?? false): ?>
                                    <div class="d-flex align-items-center justify-content-center mb-2">
                                        <i class="fas fa-phone text-success me-2"></i>
                                        <span><?php echo e($booking->user->phone); ?></span>
                                    </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Assignment Information -->
                <div class="col-md-6 mb-4">
                    <div class="card shadow-sm border-0 h-100">
                        <div class="card-header bg-white py-3">
                            <h6 class="card-title mb-0">
                                <i class="fas fa-users me-2 text-primary"></i>
                                Assignment Details
                            </h6>
                        </div>
                        <div class="card-body">
                            <?php if($booking->vendor && $booking->cab): ?>
                            <div class="assignment-info">
                                <!-- Vendor Info -->
                                <div class="d-flex align-items-center mb-3 p-2 bg-light rounded">
                                    <div class="vendor-icon bg-success text-white rounded-circle me-3">
                                        <i class="fas fa-building"></i>
                                    </div>
                                    <div>
                                        <h6 class="mb-1"><?php echo e($booking->vendor->name); ?></h6>
                                        <small class="text-muted">Vendor</small>
                                        <div class="mt-1">
                                            <small>
                                                <i class="fas fa-phone text-muted me-1"></i>
                                                <?php echo e($booking->vendor->phone ?? 'N/A'); ?>

                                            </small>
                                        </div>
                                    </div>
                                </div>

                                <!-- Cab Info -->
                                <div class="d-flex align-items-center p-2 bg-light rounded">
                                    <div class="cab-icon bg-info text-white rounded-circle me-3">
                                        <i class="fas fa-car"></i>
                                    </div>
                                    <div>
                                        <h6 class="mb-1"><?php echo e($booking->cab->cab_name); ?></h6>
                                        <small class="text-muted">
                                            <?php echo e(ucfirst($booking->cab->cab_type)); ?> • 
                                            <?php echo e($booking->cab->registration_no); ?>

                                        </small>
                                        <div class="mt-1">
                                            <small>
                                                <i class="fas fa-user text-muted me-1"></i>
                                                <?php echo e($booking->cab->driver_name ?? 'N/A'); ?>

                                            </small>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php else: ?>
                            <div class="text-center py-4">
                                <div class="empty-state-icon mb-3">
                                    <i class="fas fa-users text-muted fs-1"></i>
                                </div>
                                <h6 class="text-muted">Not Assigned</h6>
                                <p class="text-muted mb-0">No vendor or cab assigned yet</p>
                                <button class="btn btn-primary btn-sm mt-2" data-bs-toggle="modal" data-bs-target="#assignVendorModal">
                                    <i class="fas fa-user-check me-1"></i>Assign Vendor
                                </button>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Sidebar - Status & Actions -->
        <div class="col-xl-4 col-lg-5">
            <!-- Status & Payment Card -->
            <div class="card shadow-sm border-0 mb-4">
                <div class="card-header bg-white py-3">
                    <h6 class="card-title mb-0">
                        <i class="fas fa-info-circle me-2 text-primary"></i>
                        Booking Status & Actions
                    </h6>
                </div>
                <div class="card-body">
                    <!-- Booking Status -->
                    <div class="status-display text-center mb-4">
                        <?php
                            $statusConfig = [
                                'pending' => ['color' => 'warning', 'icon' => 'clock'],
                                'assigned' => ['color' => 'info', 'icon' => 'user-check'],
                                'in_progress' => ['color' => 'primary', 'icon' => 'play-circle'],
                                'completed' => ['color' => 'success', 'icon' => 'check-circle'],
                                'cancelled' => ['color' => 'danger', 'icon' => 'times-circle']
                            ];
                            $status = $statusConfig[$booking->status] ?? ['color' => 'secondary', 'icon' => 'question-circle'];
                        ?>
                        
                        <div class="status-icon bg-<?php echo e($status['color']); ?> text-white rounded-circle mx-auto mb-3">
                            <i class="fas fa-<?php echo e($status['icon']); ?> fs-4"></i>
                        </div>
                        <h4 class="text-<?php echo e($status['color']); ?> mb-2"><?php echo e(ucfirst($booking->status)); ?></h4>
                        
                        <!-- Status Update Form -->
                        <form action="<?php echo e(route('bookings.update-status', $booking)); ?>" method="POST" class="mb-3">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PATCH'); ?>
                            <div class="input-group input-group-sm">
                                <select name="status" class="form-select" onchange="this.form.submit()">
                                    <option value="pending" <?php echo e($booking->status == 'pending' ? 'selected' : ''); ?>>Pending</option>
                                    <option value="assigned" <?php echo e($booking->status == 'assigned' ? 'selected' : ''); ?>>Assigned</option>
                                    <option value="in_progress" <?php echo e($booking->status == 'in_progress' ? 'selected' : ''); ?>>In Progress</option>
                                    <option value="completed" <?php echo e($booking->status == 'completed' ? 'selected' : ''); ?>>Completed</option>
                                    <option value="cancelled" <?php echo e($booking->status == 'cancelled' ? 'selected' : ''); ?>>Cancelled</option>
                                </select>
                            </div>
                        </form>
                    </div>

                    <!-- Payment Status -->
                    <div class="payment-status text-center mb-4 p-3 bg-light rounded">
                        <div class="d-flex align-items-center justify-content-center mb-2">
                            <div class="payment-icon bg-<?php echo e($booking->payment_status == 'paid' ? 'success' : ($booking->payment_status == 'pending' ? 'warning' : 'secondary')); ?> text-white rounded-circle me-2">
                                <i class="fas fa-<?php echo e($booking->payment_status == 'paid' ? 'check' : ($booking->payment_status == 'pending' ? 'clock' : 'exclamation-triangle')); ?>"></i>
                            </div>
                            <h5 class="mb-0">Payment <?php echo e(ucfirst($booking->payment_status)); ?></h5>
                        </div>
                        
                        <!-- Payment Status Update Form -->
                        <form action="<?php echo e(route('bookings.update-payment-status', $booking)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PATCH'); ?>
                            <div class="input-group input-group-sm">
                                <select name="payment_status" class="form-select" onchange="this.form.submit()">
                                    <option value="pending" <?php echo e($booking->payment_status == 'pending' ? 'selected' : ''); ?>>Pending</option>
                                    <option value="paid" <?php echo e($booking->payment_status == 'paid' ? 'selected' : ''); ?>>Paid</option>
                                    <option value="failed" <?php echo e($booking->payment_status == 'failed' ? 'selected' : ''); ?>>Failed</option>
                                    <option value="refunded" <?php echo e($booking->payment_status == 'refunded' ? 'selected' : ''); ?>>Refunded</option>
                                </select>
                            </div>
                        </form>
                    </div>

                    <!-- Fare Information -->
                    <div class="fare-info text-center p-3 bg-primary bg-opacity-10 rounded">
                        <h6 class="text-muted mb-2">Total Fare</h6>
                        <h3 class="text-primary fw-bold">₹<?php echo e(number_format($booking->total_estimated_fare, 2)); ?></h3>
                        <small class="text-muted">Inclusive of all charges</small>
                    </div>
                </div>
            </div>

            <!-- Quick Actions -->
            <div class="card shadow-sm border-0">
                <div class="card-header bg-white py-3">
                    <h6 class="card-title mb-0">
                        <i class="fas fa-bolt me-2 text-primary"></i>
                        Quick Actions
                    </h6>
                </div>
                <div class="card-body">
                    <div class="d-grid gap-2">
                        <?php if($booking->status == 'pending' && !$booking->vendor): ?>
                        <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#assignVendorModal">
                            <i class="fas fa-user-check me-2"></i>Assign Vendor
                        </button>
                        <?php endif; ?>

                        <?php if($booking->status == 'assigned'): ?>
                        <form action="<?php echo e(route('bookings.update-status', $booking)); ?>" method="POST" class="d-grid">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PATCH'); ?>
                            <input type="hidden" name="status" value="in_progress">
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-play-circle me-2"></i>Start Trip
                            </button>
                        </form>
                        <?php endif; ?>

                        <?php if($booking->status == 'in_progress'): ?>
                        <form action="<?php echo e(route('bookings.update-status', $booking)); ?>" method="POST" class="d-grid">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PATCH'); ?>
                            <input type="hidden" name="status" value="completed">
                            <button type="submit" class="btn btn-success">
                                <i class="fas fa-check-circle me-2"></i>Complete Trip
                            </button>
                        </form>
                        <?php endif; ?>

                        <?php if($booking->status == 'pending'): ?>
                        <form action="<?php echo e(route('bookings.update-status', $booking)); ?>" method="POST" class="d-grid">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PATCH'); ?>
                            <input type="hidden" name="status" value="cancelled">
                            <button type="submit" class="btn btn-danger" onclick="return confirm('Are you sure you want to cancel this booking?')">
                                <i class="fas fa-times-circle me-2"></i>Cancel Booking
                            </button>
                        </form>
                        <?php endif; ?>

                        <div class="dropdown">
                            <button class="btn btn-outline-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown">
                                <i class="fas fa-ellipsis-v me-2"></i>More Actions
                            </button>
                            <ul class="dropdown-menu w-100">
                                <li>
                                    <a class="dropdown-item" href="<?php echo e(route('bookings.invoice', $booking)); ?>" target="_blank">
                                        <i class="fas fa-receipt me-2"></i>Generate Invoice
                                    </a>
                                </li>
                                <li>
                                    <a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#sendNotificationModal">
                                        <i class="fas fa-envelope me-2"></i>Send Notification
                                    </a>
                                </li>
                                <li><hr class="dropdown-divider"></li>
                                <li>
                                    <form action="<?php echo e(route('bookings.destroy', $booking)); ?>" method="POST" class="d-inline">
                                        <?php echo csrf_field(); ?> 
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="button" class="dropdown-item text-danger" onclick="confirmDelete()">
                                            <i class="fas fa-trash me-2"></i>Delete Booking
                                        </button>
                                    </form>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Timeline -->
            <div class="card shadow-sm border-0 mt-4">
                <div class="card-header bg-white py-3">
                    <h6 class="card-title mb-0">
                        <i class="fas fa-history me-2 text-primary"></i>
                        Booking Timeline
                    </h6>
                </div>
                <div class="card-body">
                    <div class="timeline">
                        <div class="timeline-item completed">
                            <div class="timeline-marker bg-success"></div>
                            <div class="timeline-content">
                                <h6 class="mb-1">Booking Created</h6>
                                <small class="text-muted"><?php echo e($booking->created_at->format('M d, Y h:i A')); ?></small>
                            </div>
                        </div>

                        <?php if($booking->vendor): ?>
                        <div class="timeline-item completed">
                            <div class="timeline-marker bg-info"></div>
                            <div class="timeline-content">
                                <h6 class="mb-1">Vendor Assigned</h6>
                                <small class="text-muted"><?php echo e($booking->updated_at->format('M d, Y h:i A')); ?></small>
                            </div>
                        </div>
                        <?php endif; ?>

                        <div class="timeline-item <?php echo e(in_array($booking->status, ['assigned', 'in_progress', 'completed']) ? 'completed' : 'pending'); ?>">
                            <div class="timeline-marker <?php echo e(in_array($booking->status, ['assigned', 'in_progress', 'completed']) ? 'bg-info' : 'bg-light'); ?>"></div>
                            <div class="timeline-content">
                                <h6 class="mb-1">Trip Started</h6>
                                <small class="text-muted">
                                    <?php echo e(in_array($booking->status, ['assigned', 'in_progress', 'completed']) ? 'In progress' : 'Pending'); ?>

                                </small>
                            </div>
                        </div>

                        <div class="timeline-item <?php echo e($booking->status == 'completed' ? 'completed' : 'pending'); ?>">
                            <div class="timeline-marker <?php echo e($booking->status == 'completed' ? 'bg-success' : 'bg-light'); ?>"></div>
                            <div class="timeline-content">
                                <h6 class="mb-1">Trip Completed</h6>
                                <small class="text-muted">
                                    <?php echo e($booking->status == 'completed' ? 'Successfully completed' : 'Awaiting completion'); ?>

                                </small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Assign Vendor Modal -->
<div class="modal fade" id="assignVendorModal" tabindex="-1" aria-labelledby="assignVendorModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="assignVendorModalLabel">Assign Vendor & Cab</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="<?php echo e(route('bookings.assign-vendor', $booking)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PATCH'); ?>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="vendor_id" class="form-label">Select Vendor</label>
                            <select class="form-select" id="vendor_id" name="vendor_id" required>
                                <option value="">Choose Vendor...</option>
                                <?php $__currentLoopData = $vendors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($vendor->id); ?>" <?php echo e($booking->vendor_id == $vendor->id ? 'selected' : ''); ?>>
                                    <?php echo e($vendor->name); ?> - <?php echo e($vendor->phone); ?>

                                </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="cab_id" class="form-label">Select Cab</label>
                            <select class="form-select" id="cab_id" name="cab_id" required>
                                <option value="">Choose Cab...</option>
                                <?php $__currentLoopData = $cabs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($cab->id); ?>" <?php echo e($booking->cab_id == $cab->id ? 'selected' : ''); ?>>
                                    <?php echo e($cab->cab_name); ?> (<?php echo e($cab->registration_no); ?>)
                                </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="driver_notes" class="form-label">Driver Notes (Optional)</label>
                        <textarea class="form-control" id="driver_notes" name="driver_notes" rows="3" placeholder="Any special instructions for the driver..."><?php echo e($booking->driver_notes); ?></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Assign Vendor</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Send Notification Modal -->
<div class="modal fade" id="sendNotificationModal" tabindex="-1" aria-labelledby="sendNotificationModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="sendNotificationModalLabel">Send Notification</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="<?php echo e(route('bookings.send-notification', $booking)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="notification_type" class="form-label">Notification Type</label>
                        <select class="form-select" id="notification_type" name="notification_type" required>
                            <option value="status_update">Status Update</option>
                            <option value="payment_reminder">Payment Reminder</option>
                            <option value="trip_reminder">Trip Reminder</option>
                            <option value="custom">Custom Message</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="message" class="form-label">Message</label>
                        <textarea class="form-control" id="message" name="message" rows="4" required placeholder="Enter your notification message..."></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Send Notification</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<style>
    .bg-gradient-primary {
        background: linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%) !important;
    }
    
    .location-icon, .status-icon, .payment-icon, .vendor-icon, .cab-icon {
        width: 50px;
        height: 50px;
        display: flex;
        align-items: center;
        justify-content: center;
    }
    
    .customer-avatar {
        width: 80px;
        height: 80px;
        display: flex;
        align-items: center;
        justify-content: center;
    }
    
    .route-display {
        background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
    }
    
    .detail-card {
        display: flex;
        align-items: center;
        padding: 1rem;
        background: #f8f9fa;
        border-radius: 0.75rem;
        border: 1px solid #e9ecef;
    }
    
    .detail-icon {
        width: 45px;
        height: 45px;
        border-radius: 0.5rem;
        display: flex;
        align-items: center;
        justify-content: center;
        margin-right: 1rem;
        color: white;
        font-size: 1.1rem;
    }
    
    .detail-label {
        font-size: 0.875rem;
        color: #6c757d;
        margin-bottom: 0.25rem;
        font-weight: 500;
    }
    
    .detail-value {
        font-size: 1rem;
        font-weight: 600;
        color: var(--text-dark);
        margin-bottom: 0;
    }
    
    /* Timeline Styles */
    .timeline {
        position: relative;
        padding-left: 2rem;
    }
    
    .timeline::before {
        content: '';
        position: absolute;
        left: 15px;
        top: 0;
        bottom: 0;
        width: 2px;
        background: #e9ecef;
    }
    
    .timeline-item {
        position: relative;
        margin-bottom: 1.5rem;
    }
    
    .timeline-marker {
        position: absolute;
        left: -2rem;
        top: 0;
        width: 12px;
        height: 12px;
        border-radius: 50%;
        border: 2px solid white;
    }
    
    .timeline-item.completed .timeline-marker {
        background: var(--success);
    }
    
    .timeline-item.pending .timeline-marker {
        background: #e9ecef;
    }
    
    .timeline-content h6 {
        font-size: 0.9rem;
        margin-bottom: 0.25rem;
    }
    
    .card-header {
        background: linear-gradient(135deg, #f8fafc 0%, #ffffff 100%);
        border-bottom: 1px solid rgba(0,0,0,0.05);
    }
    
    .breadcrumb {
        background: transparent;
        padding: 0;
        margin-bottom: 0.5rem;
    }
    
    .empty-state-icon {
        opacity: 0.5;
    }
    
    .form-label {
        font-size: 0.875rem;
        font-weight: 500;
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
function confirmDelete() {
    Swal.fire({
        title: 'Delete Booking?',
        html: `You are about to delete booking <strong>#<?php echo e($booking->id); ?></strong>. This action cannot be undone.`,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#3085d6',
        confirmButtonText: 'Yes, delete it!',
        cancelButtonText: 'Cancel',
        reverseButtons: true,
        backdrop: true
    }).then((result) => {
        if (result.isConfirmed) {
            event.target.closest('form').submit();
        }
    });
}

// Initialize tooltips
document.addEventListener('DOMContentLoaded', function() {
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    var tooltipList = tooltipTriggerList.map(function(tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
});

// Auto-submit forms when dropdown changes
document.querySelectorAll('select[onchange]').forEach(select => {
    select.addEventListener('change', function() {
        this.form.submit();
    });
});
</script>

<!-- SweetAlert2 for better confirmations -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/tour-app/resources/views/bookings/show.blade.php ENDPATH**/ ?>
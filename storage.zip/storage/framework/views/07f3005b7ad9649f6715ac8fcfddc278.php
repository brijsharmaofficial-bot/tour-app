<?php $__env->startSection('content'); ?>
<h2>Add Vehicle</h2>
<a href="<?php echo e(route('vehicles.index')); ?>" class="btn btn-secondary mb-3">Back</a>

<?php echo $__env->make('vehicles.partials.form', ['route' => route('vehicles.store'), 'method' => 'POST', 'button' => 'Create Vehicle'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/tour-app/resources/views/vehicles/create.blade.php ENDPATH**/ ?>
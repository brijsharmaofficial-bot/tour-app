<?php $__env->startSection('title', 'Create Booking'); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-4">
  <h4 class="fw-bold mb-3">
    <i class="bi bi-plus-circle text-success me-2"></i> New Booking
  </h4>

  <form id="bookingForm" method="POST" action="<?php echo e(route('bookings.store')); ?>" class="card shadow-sm border-0 p-4">
    <?php echo csrf_field(); ?>
    <div class="row g-3">

      
      <div class="col-md-4">
        <label class="form-label">Customer</label>
        <select name="user_id" class="form-select">
          <option value="">Select User</option>
          <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($u->id); ?>"><?php echo e($u->name); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </div>

      
      <div class="col-md-4 position-relative">
        <label class="form-label">Package</label>
        <input type="text" id="packageSearch" class="form-control" placeholder="Search Package (City or Trip Type)...">
        <input type="hidden" name="package_id" id="package_id">
        <ul id="packageResults" class="list-group position-absolute w-100 shadow-sm" style="z-index:1000; display:none;"></ul>
      </div>

      
      <div class="col-md-4">
        <label class="form-label">Vendor</label>
        <select name="vendor_id" id="vendor_id" class="form-select">
          <option value="">Select Vendor</option>
          <?php $__currentLoopData = $vendors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($v->id); ?>"><?php echo e($v->name); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </div>

      
      <div class="col-md-4">
        <label class="form-label">Cab</label>
        <select name="cab_id" id="cab_id" class="form-select">
          <option value="">Select Vendor First</option>
        </select>
      </div>

      
      <div class="col-md-4">
        <label class="form-label">From City</label>
        <select name="from_city_id" id="from_city_id" class="form-select">
          <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($city->id); ?>"><?php echo e($city->name); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </div>

      
      <div class="col-md-4">
        <label class="form-label">To City</label>
        <select name="to_city_id" id="to_city_id" class="form-select">
          <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($city->id); ?>"><?php echo e($city->name); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </div>

      
      <div class="col-md-4">
        <label class="form-label">Pickup Date</label>
        <input type="date" name="pickup_date" class="form-control" required>
      </div>
      <div class="col-md-4">
        <label class="form-label">Pickup Time</label>
        <input type="time" name="pickup_time" class="form-control" required>
      </div>

      
      <div class="col-md-6">
        <label class="form-label">Pickup Address</label>
        <input type="text" name="pickup_address" class="form-control">
      </div>
      <div class="col-md-6">
        <label class="form-label">Drop Address</label>
        <input type="text" name="drop_address" class="form-control">
      </div>

      
      <div class="col-md-4">
        <label class="form-label">Distance (km)</label>
        <input type="number" step="0.01" name="distance_km" id="distance_km" class="form-control">
      </div>
      <div class="col-md-4">
        <label class="form-label">Fare Without GST</label>
        <input type="number" step="0.01" name="fare_without_gst" id="fare_without_gst" class="form-control">
      </div>
      <div class="col-md-4">
        <label class="form-label">Total Estimated Fare (₹)</label>
        <input type="number" step="0.01" name="total_estimated_fare" id="total_estimated_fare" class="form-control">
      </div>

      
      <div class="col-md-4">
        <label class="form-label">Status</label>
        <select name="status" class="form-select">
          <option value="pending">Pending</option>
          <option value="assigned">Assigned</option>
          <option value="completed">Completed</option>
          <option value="cancelled">Cancelled</option>
        </select>
      </div>

      
      <div class="col-md-4">
        <label class="form-label">Payment Status</label>
        <select name="payment_status" class="form-select">
          <option value="unpaid">Unpaid</option>
          <option value="paid">Paid</option>
        </select>
      </div>
    </div>

    <div class="mt-4 text-end">
      <button class="btn btn-success"><i class="bi bi-check-circle"></i> Save</button>
      <a href="<?php echo e(route('bookings.index')); ?>" class="btn btn-secondary">Cancel</a>
    </div>
  </form>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', function () {
  const vendorSelect = document.getElementById('vendor_id');
  const cabSelect = document.getElementById('cab_id');
  const pkgSearch = document.getElementById('packageSearch');
  const pkgResults = document.getElementById('packageResults');
  const pkgHidden = document.getElementById('package_id');

  // 🔍 Autocomplete search for packages
  pkgSearch.addEventListener('input', async () => {
    const q = pkgSearch.value.trim();
    pkgResults.innerHTML = '';
    pkgResults.style.display = 'none';

    if (q.length < 2) return; // Minimum 2 chars

    const res = await fetch(`/admin/packages/search?q=${q}`);
    const data = await res.json();

    if (data.length) {
      pkgResults.innerHTML = data.map(p => `
        <li class="list-group-item list-group-item-action"
            data-id="${p.id}">
          ${p.trip_type_name} — ${p.from_city_name} → ${p.to_city_name || 'N/A'}
        </li>`).join('');
      pkgResults.style.display = 'block';
    }
  });

  // Select package from dropdown
  pkgResults.addEventListener('click', e => {
    if (e.target.matches('li')) {
      pkgSearch.value = e.target.textContent.trim();
      pkgHidden.value = e.target.dataset.id;
      pkgResults.style.display = 'none';
    }
  });

  // 💡 Vendor wise cabs
  vendorSelect.addEventListener('change', async () => {
    const id = vendorSelect.value;
    cabSelect.innerHTML = '<option>Loading...</option>';
    if (!id) return;
    const res = await fetch(`/admin/get-cabs?vendor_id=${id}`);
    const data = await res.json();
    cabSelect.innerHTML = data.length
      ? data.map(c => `<option value="${c.id}">${c.cab_name} (${c.cab_type})</option>`).join('')
      : '<option>No cabs available</option>';
  });
});
</script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('styles'); ?>
<style>
#packageResults li:hover { background:#f8f9fa; cursor:pointer; }
</style>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/tour-app/resources/views/bookings/create.blade.php ENDPATH**/ ?>
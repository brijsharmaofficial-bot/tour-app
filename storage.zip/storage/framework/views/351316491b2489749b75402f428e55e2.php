
<?php $__env->startSection('title', 'Create Page'); ?>

<?php $__env->startSection('content'); ?>
     <div class="container">
        <h2>City List</h2>

        <a href="<?php echo e(route('cities.create')); ?>" class="btn btn-success mb-3">Add New City</a>

        <table class="table table-bordered" id="citydatatable">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>City Name</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($city->id); ?></td>
                        <td><?php echo e($city->name); ?></td>
                        
                        <td>
                            <a href="<?php echo e(route('cities.edit', $city->id)); ?>" class="btn btn-sm btn-primary">Edit</a>

                            <form action="<?php echo e(route('cities.destroy', $city->id)); ?>" method="POST" style="display:inline-block;" onsubmit="return confirm('Are you sure you want to delete this city?');">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/tour-app/resources/views/cities/index.blade.php ENDPATH**/ ?>
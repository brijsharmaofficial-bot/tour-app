
<?php $__env->startSection('title', 'Edit Page'); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-4">
    <h2 class="fw-bold mb-4">Edit Page</h2>

    <div class="card shadow-sm border-0">
        <div class="card-body">
            <form method="POST" action="<?php echo e(route('pages.update', $page->id)); ?>">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                
                <div class="mb-3">
                    <label for="title" class="form-label fw-semibold">Title</label>
                    <input 
                        type="text" 
                        class="form-control" 
                        id="title" 
                        name="title" 
                        value="<?php echo e(old('title', $page->title)); ?>" 
                        required
                    >
                </div>

                
                <div class="mb-3">
                    <label for="slug" class="form-label fw-semibold">Slug</label>
                    <input 
                        type="text" 
                        class="form-control" 
                        id="slug" 
                        name="slug" 
                        value="<?php echo e(old('slug', $page->slug)); ?>" 
                        required
                    >
                </div>

                
                <div class="mb-3">
                    <label for="editor" class="form-label fw-semibold">Content</label>
                    <textarea 
                        class="form-control" 
                        id="editor" 
                        name="content" 
                        rows="10"
                    ><?php echo e(old('content', $page->content)); ?></textarea>
                </div>

                
                <div class="mb-3">
                    <label for="status" class="form-label fw-semibold">Status</label>
                    <select class="form-select" id="status" name="status">
                        <option value="draft" <?php echo e($page->status === 'draft' ? 'selected' : ''); ?>>Draft</option>
                        <option value="published" <?php echo e($page->status === 'published' ? 'selected' : ''); ?>>Published</option>
                    </select>
                </div>

                
                <div class="text-end">
                    <button type="submit" class="btn btn-success px-4">
                        <i class="fas fa-save me-2"></i>Update Page
                    </button>
                    <a href="<?php echo e(route('pages.index')); ?>" class="btn btn-secondary">
                        <i class="fas fa-times me-2"></i>Cancel
                    </a>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>

<script src="https://cdn.ckeditor.com/ckeditor5/41.0.0/classic/ckeditor.js"></script>

<script>
document.addEventListener('DOMContentLoaded', function () {
    // ✅ Initialize CKEditor
    ClassicEditor
        .create(document.querySelector('#editor'), {
            toolbar: [
                'heading', '|', 'bold', 'italic', 'link',
                'bulletedList', 'numberedList', '|',
                'blockQuote', 'insertTable', 'undo', 'redo'
            ],
        })
        .catch(error => console.error('CKEditor error:', error));

    // ✅ Auto-generate slug from title if user edits title
    const titleInput = document.getElementById('title');
    const slugInput = document.getElementById('slug');

    titleInput.addEventListener('input', function () {
        const slug = this.value
            .toLowerCase()
            .trim()
            .replace(/[^\w\s-]/g, '')
            .replace(/[\s_-]+/g, '-')
            .replace(/^-+|-+$/g, '');
        slugInput.value = slug;
    });
});
</script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('styles'); ?>
<style>
.ck-editor__editable {
    min-height: 300px;
}
.ck-content {
    font-family: "Inter", sans-serif;
    line-height: 1.6;
}
</style>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/tour-app/resources/views/pages/edit.blade.php ENDPATH**/ ?>
<?php if($errors->any()): ?>
<div class="alert alert-danger">
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($error); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php endif; ?>

<form action="<?php echo e($route); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <?php if($method === 'PUT'): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>

    <div class="row g-3">
        <div class="col-md-6">
            <label class="form-label">Vendor</label>
            <select name="vendor_id" class="form-select">
                <option value="">-- Select Vendor --</option>
                <?php $__currentLoopData = $vendors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($vendor->id); ?>" <?php echo e(old('vendor_id', $vehicle->vendor_id ?? '') == $vendor->id ? 'selected' : ''); ?>>
                    <?php echo e($vendor->name); ?> (<?php echo e($vendor->company_name); ?>)
                </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="col-md-6">
            <label class="form-label">Vehicle Type</label>
            <input type="text" name="vehicle_type" value="<?php echo e(old('vehicle_type', $vehicle->vehicle_type ?? '')); ?>" class="form-control">
        </div>
        <div class="col-md-6">
            <label class="form-label">Vehicle Number</label>
            <input type="text" name="vehicle_number" value="<?php echo e(old('vehicle_number', $vehicle->vehicle_number ?? '')); ?>" class="form-control">
        </div>
        <div class="col-md-6">
            <label class="form-label">Vehicle Model</label>
            <input type="text" name="vehicle_model" value="<?php echo e(old('vehicle_model', $vehicle->vehicle_model ?? '')); ?>" class="form-control">
        </div>
        <div class="col-md-6">
            <label class="form-label">Vehicle Year</label>
            <input type="number" name="vehicle_year" value="<?php echo e(old('vehicle_year', $vehicle->vehicle_year ?? '')); ?>" class="form-control">
        </div>
        <div class="col-md-6">
            <label class="form-label">License Number</label>
            <input type="text" name="license_number" value="<?php echo e(old('license_number', $vehicle->license_number ?? '')); ?>" class="form-control">
        </div>
        <div class="col-md-6">
            <label class="form-label">License Expiry</label>
            <input type="date" name="license_expiry" value="<?php echo e(old('license_expiry', $vehicle->license_expiry ?? '')); ?>" class="form-control">
        </div>
        <div class="col-md-6">
            <label class="form-label">Insurance Number</label>
            <input type="text" name="insurance_number" value="<?php echo e(old('insurance_number', $vehicle->insurance_number ?? '')); ?>" class="form-control">
        </div>
        <div class="col-md-6">
            <label class="form-label">Insurance Expiry</label>
            <input type="date" name="insurance_expiry" value="<?php echo e(old('insurance_expiry', $vehicle->insurance_expiry ?? '')); ?>" class="form-control">
        </div>
        <div class="col-md-6">
            <label class="form-label">Upload Documents</label>
            <input type="file" name="vehicle_documents" class="form-control">
        </div>
        <div class="col-12">
            <button type="submit" class="btn btn-primary"><?php echo e($button); ?></button>
        </div>
    </div>
</form>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/tour-app/resources/views/vehicles/partials/form.blade.php ENDPATH**/ ?>


<?php $__env->startSection('title', 'Create City'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h2>Edit City</h2>

        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul class="mb-0">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <form method="POST" action="<?php echo e(route('cities.update', $city->id)); ?>">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="mb-3">
                <label for="name" class="form-label">City Name</label>
                <input type="text" name="name" id="name" class="form-control" required value="<?php echo e(old('name', $city->name)); ?>">
            </div>
            <button type="submit" class="btn btn-primary">Update City</button>
            <a href="<?php echo e(route('cities.index')); ?>" class="btn btn-secondary">Back</a>
        </form>
    </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/tour-app/resources/views/cities/edit.blade.php ENDPATH**/ ?>


<?php $__env->startSection('title', 'Create Page'); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-4">
    <h2 class="fw-bold mb-4">Create New Page</h2>

    <div class="card shadow-sm border-0">
        <div class="card-body">
            <form method="POST" action="<?php echo e(route('pages.store')); ?>">
                <?php echo csrf_field(); ?>

                
                <div class="mb-3">
                    <label for="title" class="form-label fw-semibold">Title</label>
                    <input type="text" class="form-control" id="title" name="title" placeholder="Enter page title..." required>
                </div>

                
                <div class="mb-3">
                    <label for="slug" class="form-label fw-semibold">Slug (auto-generated)</label>
                    <input type="text" class="form-control" id="slug" name="slug" placeholder="auto-generated-slug" required>
                </div>

                
                <div class="mb-3">
                    <label for="editor" class="form-label fw-semibold">Content</label>
                    <textarea class="form-control" id="editor" name="content" rows="10" placeholder="Write your content here..."></textarea>
                </div>

                
                <div class="mb-3">
                    <label for="status" class="form-label fw-semibold">Status</label>
                    <select class="form-select" id="status" name="status" required>
                        <option value="draft">Draft</option>
                        <option value="published">Published</option>
                    </select>
                </div>

                
                <div class="text-end">
                    <button type="submit" class="btn btn-primary px-4">
                        <i class="fas fa-save me-2"></i>Create Page
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>

<script src="https://cdn.ckeditor.com/ckeditor5/41.0.0/classic/ckeditor.js"></script>

<script>
document.addEventListener('DOMContentLoaded', function () {
    // ✅ Initialize CKEditor
    ClassicEditor
        .create(document.querySelector('#editor'), {
            toolbar: [
                'heading', '|', 'bold', 'italic', 'link', 'bulletedList', 'numberedList', '|', 'blockQuote', 'insertTable', 'undo', 'redo'
            ],
        })
        .catch(error => console.error('CKEditor error:', error));

    // ✅ Auto-generate slug from title
    const titleInput = document.getElementById('title');
    const slugInput = document.getElementById('slug');

    titleInput.addEventListener('input', function () {
        const slug = this.value
            .toLowerCase()
            .trim()
            .replace(/[^\w\s-]/g, '')
            .replace(/[\s_-]+/g, '-')
            .replace(/^-+|-+$/g, '');
        slugInput.value = slug;
    });
});
</script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('styles'); ?>
<style>
.ck-editor__editable {
    min-height: 300px;
}
.ck-content {
    font-family: "Inter", sans-serif;
    line-height: 1.6;
}
</style>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/tour-app/resources/views/pages/create.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
<h2>Vehicle Details</h2>
<a href="<?php echo e(route('vehicles.index')); ?>" class="btn btn-secondary mb-3">Back</a>

<div class="card">
    <div class="card-body">
        <p><strong>Vendor:</strong> <?php echo e($vehicle->vendor->name ?? 'N/A'); ?></p>
        <p><strong>Type:</strong> <?php echo e($vehicle->vehicle_type); ?></p>
        <p><strong>Number:</strong> <?php echo e($vehicle->vehicle_number); ?></p>
        <p><strong>Model:</strong> <?php echo e($vehicle->vehicle_model); ?></p>
        <p><strong>Year:</strong> <?php echo e($vehicle->vehicle_year); ?></p>
        <p><strong>License:</strong> <?php echo e($vehicle->license_number); ?> (Expiry: <?php echo e($vehicle->license_expiry); ?>)</p>
        <p><strong>Insurance:</strong> <?php echo e($vehicle->insurance_number); ?> (Expiry: <?php echo e($vehicle->insurance_expiry); ?>)</p>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/tour-app/resources/views/vehicles/show.blade.php ENDPATH**/ ?>
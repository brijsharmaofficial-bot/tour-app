
<?php $__env->startSection('title', 'Edit Page'); ?>

<?php $__env->startSection('content'); ?>
    <h2 class="mb-4">Edit Page</h2>

    <div class="card">
        <div class="card-body">
            <form method="POST" action="<?php echo e(route('pages.update', $page->id)); ?>">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="form-group mb-3">
                    <label for="title">Title</label>
                    <input type="text" class="form-control" id="title" name="title" value="<?php echo e(old('title', $page->title)); ?>" required>
                </div>

                <div class="form-group mb-3">
                    <label for="slug">Slug</label>
                    <input type="text" class="form-control" id="slug" name="slug" value="<?php echo e(old('slug', $page->slug)); ?>" required>
                </div>

                <div class="form-group mb-3">
                    <label for="editor">Content</label>
                    <textarea class="form-control" id="editor" name="content"><?php echo e(old('content', $page->content)); ?></textarea>
                </div>

                <div class="form-group mb-3">
                    <label for="status">Status</label>
                    <select class="form-control" id="status" name="status">
                        <option value="draft" <?php echo e($page->status === 'draft' ? 'selected' : ''); ?>>Draft</option>
                        <option value="published" <?php echo e($page->status === 'published' ? 'selected' : ''); ?>>Published</option>
                    </select>
                </div>

                <button type="submit" class="btn btn-primary">Update Page</button>
                <a href="<?php echo e(route('pages.index')); ?>" class="btn btn-secondary">Cancel</a>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/tour-app/resources/views/packages/oneway/edit.blade.php ENDPATH**/ ?>
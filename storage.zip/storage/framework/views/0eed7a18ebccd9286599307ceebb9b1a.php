<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-3">
    <h2>Vehicles</h2>
    <a href="<?php echo e(route('vehicles.create')); ?>" class="btn btn-primary">Add Vehicle</a>
</div>

<?php if(session('success')): ?>
<div class="alert alert-success"><?php echo e(session('success')); ?></div>
<?php endif; ?>

<table class="table table-bordered table-striped">
    <thead class="table-dark">
        <tr>
            <th>ID</th>
            <th>Vendor</th>
            <th>Type</th>
            <th>Number</th>
            <th>Model</th>
            <th>Year</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $vehicles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td><?php echo e($vehicle->id); ?></td>
            <td><?php echo e($vehicle->vendor->name ?? 'N/A'); ?></td>
            <td><?php echo e($vehicle->vehicle_type); ?></td>
            <td><?php echo e($vehicle->vehicle_number); ?></td>
            <td><?php echo e($vehicle->vehicle_model); ?></td>
            <td><?php echo e($vehicle->vehicle_year); ?></td>
            <td>
                <a href="<?php echo e(route('vehicles.show', $vehicle)); ?>" class="btn btn-info btn-sm">View</a>
                <a href="<?php echo e(route('vehicles.edit', $vehicle)); ?>" class="btn btn-warning btn-sm">Edit</a>
                <form action="<?php echo e(route('vehicles.destroy', $vehicle)); ?>" method="POST" class="d-inline">
                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                    <button class="btn btn-danger btn-sm" onclick="return confirm('Delete this vehicle?')">Delete</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr><td colspan="7" class="text-center">No vehicles found.</td></tr>
        <?php endif; ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/tour-app/resources/views/vehicles/index.blade.php ENDPATH**/ ?>
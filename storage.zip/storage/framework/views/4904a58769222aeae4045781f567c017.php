
<?php $__env->startSection('title', 'Create Page'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
        <h2>Vehicle Types</h2>

        <?php if(session('success')): ?>
            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>

        <a href="<?php echo e(route('vehicle-types.create')); ?>" class="btn btn-success mb-3">Add Vehicle Type</a>

        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Icon</th>            
                    <th>Rate per Km</th>
                    <th>Rate per Max Km</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $vehicleTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($vehicle->id); ?></td>
                        <td><?php echo e($vehicle->name); ?></td>
                        <td><img src="<?php echo e(asset($vehicle->icon)); ?>" alt="Icon" style="max-width: 60px;"></td>                  
                        <td><?php echo e($vehicle->rate_per_km); ?></td>
                        <td><?php echo e($vehicle->rate_per_max_km); ?></td>
                        <td>
                            <a href="<?php echo e(route('vehicle-types.edit', $vehicle->id)); ?>" class="btn btn-sm btn-primary">Edit</a>
                            <form action="<?php echo e(route('vehicle-types.destroy', $vehicle->id)); ?>" method="POST" style="display:inline-block;" onsubmit="return confirm('Are you sure?');">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button class="btn btn-sm btn-danger">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/tour-app/resources/views/vehicle_types/index.blade.php ENDPATH**/ ?>
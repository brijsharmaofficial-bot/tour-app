<?php $__env->startSection('title', 'Bookings Management'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid py-4">

    <!-- Header Section -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h4 class="fw-bold mb-1">Bookings Management</h4>
            <p class="text-muted mb-0">Manage all customer bookings and assignments</p>
        </div>
        <a href="<?php echo e(route('bookings.create')); ?>" class="btn btn-primary d-none">
            <i class="fas fa-plus-circle me-2"></i> Create New Booking
        </a>
    </div>

    <!-- Alert Messages -->
    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show d-flex align-items-center" role="alert">
            <i class="fas fa-check-circle me-2 fs-5"></i>
            <div class="flex-grow-1"><?php echo e(session('success')); ?></div>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show d-flex align-items-center" role="alert">
            <i class="fas fa-exclamation-circle me-2 fs-5"></i>
            <div class="flex-grow-1"><?php echo e(session('error')); ?></div>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

        <!-- Stats Cards -->
        <div class="row mb-4">
        <div class="col-xl-2 col-md-4 col-6 mb-3">
            <div class="card stat-card bg-primary bg-opacity-10 border-0">
                <div class="card-body text-center">
                    <div class="stat-icon-lg bg-primary text-white rounded-circle mx-auto mb-3">
                        <i class="fas fa-list-alt fs-5"></i>
                    </div>
                    <h3 class="stat-value text-primary mb-1"><?php echo e($bookings->count()); ?></h3>
                    <p class="stat-label text-muted mb-0">Total Bookings</p>
                </div>
            </div>
        </div>
        <div class="col-xl-2 col-md-4 col-6 mb-3">
            <div class="card stat-card bg-warning bg-opacity-10 border-0">
                <div class="card-body text-center">
                    <div class="stat-icon-lg bg-warning text-white rounded-circle mx-auto mb-3">
                        <i class="fas fa-clock fs-5"></i>
                    </div>
                    <h3 class="stat-value text-warning mb-1"><?php echo e($bookings->where('status', 'pending')->count()); ?></h3>
                    <p class="stat-label text-muted mb-0">Pending</p>
                </div>
            </div>
        </div>
        <div class="col-xl-2 col-md-4 col-6 mb-3">
            <div class="card stat-card bg-info bg-opacity-10 border-0">
                <div class="card-body text-center">
                    <div class="stat-icon-lg bg-info text-white rounded-circle mx-auto mb-3">
                        <i class="fas fa-car fs-5"></i>
                    </div>
                    <h3 class="stat-value text-info mb-1"><?php echo e($bookings->where('status', 'assigned')->count()); ?></h3>
                    <p class="stat-label text-muted mb-0">Assigned</p>
                </div>
            </div>
        </div>
        <div class="col-xl-2 col-md-4 col-6 mb-3">
            <div class="card stat-card bg-success bg-opacity-10 border-0">
                <div class="card-body text-center">
                    <div class="stat-icon-lg bg-success text-white rounded-circle mx-auto mb-3">
                        <i class="fas fa-check-circle fs-5"></i>
                    </div>
                    <h3 class="stat-value text-success mb-1"><?php echo e($bookings->where('status', 'completed')->count()); ?></h3>
                    <p class="stat-label text-muted mb-0">Completed</p>
                </div>
            </div>
        </div>
        <div class="col-xl-2 col-md-4 col-6 mb-3">
            <div class="card stat-card bg-danger bg-opacity-10 border-0">
                <div class="card-body text-center">
                    <div class="stat-icon-lg bg-danger text-white rounded-circle mx-auto mb-3">
                        <i class="fas fa-times-circle fs-5"></i>
                    </div>
                    <h3 class="stat-value text-danger mb-1"><?php echo e($bookings->where('status', 'cancelled')->count()); ?></h3>
                    <p class="stat-label text-muted mb-0">Cancelled</p>
                </div>
            </div>
        </div>
        <div class="col-xl-2 col-md-4 col-6 mb-3">
            <div class="card stat-card bg-secondary bg-opacity-10 border-0">
                <div class="card-body text-center">
                    <div class="stat-icon-lg bg-secondary text-white rounded-circle mx-auto mb-3">
                        <i class="fas fa-money-bill-wave fs-5"></i>
                    </div>
                    <h3 class="stat-value text-secondary mb-1"><?php echo e($bookings->where('payment_status', 'paid')->count()); ?></h3>
                    <p class="stat-label text-muted mb-0">Paid</p>
                </div>
            </div>
        </div>
    </div>

    <!-- Filter Controls -->
    <div class="card shadow-sm border-0 mb-4">
        <div class="card-body py-3">
            <div class="row g-3 align-items-center">
                <div class="col-md-8">
                    <div class="d-flex flex-wrap gap-2">
                        <button class="btn btn-outline-primary filter-btn active" data-status="">All</button>
                        <button class="btn btn-outline-warning filter-btn" data-status="pending">Pending</button>
                        <button class="btn btn-outline-info filter-btn" data-status="assigned">Assigned</button>
                        <button class="btn btn-outline-success filter-btn" data-status="completed">Completed</button>
                        <button class="btn btn-outline-danger filter-btn" data-status="cancelled">Cancelled</button>
                    </div>
                </div>
                <div class="col-md-4 text-end">
                    <div class="input-group">
                        <span class="input-group-text bg-light border-end-0">
                            <i class="fas fa-calendar text-muted"></i>
                        </span>
                        <input type="date" class="form-control" id="dateFilter">
                        <button class="btn btn-outline-secondary" type="button" id="clearDateFilter">
                            <i class="fas fa-times"></i>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bookings Table -->
    <div class="card shadow-sm border-0">
        <div class="card-header bg-white py-3 border-bottom d-flex justify-content-between align-items-center">
            <h5 class="card-title mb-0">
                <i class="fas fa-list me-2 text-primary"></i> All Bookings
            </h5>
            <div class="d-flex gap-2">
                <button class="btn btn-outline-secondary btn-sm" id="refreshTable">
                    <i class="fas fa-sync-alt me-1"></i> Refresh
                </button>
                <button class="btn btn-outline-primary btn-sm" id="exportBtn">
                    <i class="fas fa-download me-1"></i> Export
                </button>
            </div>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table id="bookingsTable" class="table table-hover align-middle mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>#</th>
                            <th>Booking</th>
                            <th>Customer</th>
                            <th>Route</th>
                            <th>Date & Time</th>
                            <th>Vendor</th>
                            <th>Status</th>
                            <th>Payment</th>
                            <th class="text-center">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr data-status="<?php echo e($booking->status); ?>" data-date="<?php echo e($booking->pickup_date); ?>">
                            <td><?php echo e($loop->iteration); ?></td>
                            <td>
                                <strong>#BK<?php echo e(str_pad($booking->id, 6, '0', STR_PAD_LEFT)); ?></strong><br>
                                <small class="text-muted"><?php echo e($booking->created_at->format('d M, Y')); ?></small>
                            </td>
                            <td>
                                <strong><?php echo e($booking->user->name ?? 'Guest'); ?></strong><br>
                                <small class="text-muted"><?php echo e($booking->user->email ?? 'N/A'); ?></small>
                            </td>
                            <td>
                                <small><i class="fas fa-map-marker-alt text-danger"></i> <?php echo e($booking->fromCity->name ?? 'N/A'); ?></small><br>
                                <small><i class="fas fa-flag-checkered text-success"></i> <?php echo e($booking->toCity->name ?? 'N/A'); ?></small>
                            </td>
                            <td>
                                <strong><?php echo e($booking->pickup_date); ?></strong><br>
                                <small><?php echo e($booking->pickup_time); ?></small>
                            </td>
                            <td>
                                <?php if($booking->vendor): ?>
                                    <div class="d-flex align-items-center">
                                        <div class="vendor-avatar bg-primary text-white rounded-circle me-2 d-flex align-items-center justify-content-center" style="width: 32px; height: 32px; font-size: 12px;">
                                            <?php echo e(substr($booking->vendor->name, 0, 1)); ?>

                                        </div>
                                        <div>
                                            <strong class="d-block"><?php echo e($booking->vendor->name); ?></strong>
                                            <small class="text-muted"><?php echo e($booking->vendor->phone ?? 'No Phone'); ?></small>
                                        </div>
                                    </div>
                                <?php else: ?>
                                    <span class="badge bg-light text-muted">Not Assigned</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span class="badge bg-<?php echo e([
                                    'pending' => 'warning',
                                    'assigned' => 'info',
                                    'completed' => 'success',
                                    'cancelled' => 'danger'
                                ][$booking->status] ?? 'secondary'); ?>">
                                    <?php echo e(ucfirst($booking->status)); ?>

                                </span>
                            </td>
                            <td>
                                <span class="badge bg-<?php echo e($booking->payment_status == 'paid' ? 'success' : 'secondary'); ?>">
                                    <?php echo e(ucfirst($booking->payment_status)); ?>

                                </span>
                            </td>
                            <td class="text-center">
                                <a href="<?php echo e(route('bookings.show', $booking)); ?>" class="btn btn-sm btn-info text-white" data-bs-toggle="tooltip" title="View">
                                    <i class="fas fa-eye"></i>
                                </a>
                                <!-- <a href="<?php echo e(route('bookings.edit', $booking)); ?>" class="btn btn-sm btn-warning" data-bs-toggle="tooltip" title="Edit">
                                    <i class="fas fa-edit"></i>
                                </a> -->
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<style>
.stat-card {
    transition: transform 0.3s ease, box-shadow 0.3s ease;
}

.stat-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 8px 25px rgba(0,0,0,0.1);
}

.stat-icon-lg {
    width: 50px;
    height: 50px;
    display: flex;
    align-items: center;
    justify-content: center;
}

.stat-label {
    font-size: 0.875rem;
    font-weight: 500;
}

.stat-value {
    font-weight: 700;
    color: var(--text-dark);
    font-size: 1.5rem;
}

.table th { 
    font-size: 0.875rem; 
    text-transform: uppercase; 
}

.filter-btn.active { 
    background-color: var(--bs-primary); 
    color: white; 
}

.dataTables_filter input { 
    width: 200px !important; 
}

.vendor-avatar {
    font-weight: bold;
}

/* Vendor column specific styling */
td:nth-child(6) {
    min-width: 180px;
}
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
$(document).ready(function () {

    // ✅ Initialize DataTable first
    const table = $('#bookingsTable').DataTable({
        destroy: true, // ✅ allows reinitialization
        order: [[0, 'desc']],
        responsive: true,
        columnDefs: [
            { responsivePriority: 1, targets: 1 }, // Booking ID
            { responsivePriority: 2, targets: 2 }, // Customer
            { responsivePriority: 3, targets: 8 }, // Actions
            { responsivePriority: 4, targets: 3 }, // Route
            { responsivePriority: 5, targets: 6 }, // Status
            { responsivePriority: 6, targets: 7 }, // Payment
            { responsivePriority: 7, targets: 5 }, // Vendor
            { responsivePriority: 8, targets: 4 }, // Date & Time
            { responsivePriority: 9, targets: 0 }  // #
        ]
    });

    // ✅ STATUS FILTER — working for all + case-insensitive
    $('.filter-btn').on('click', function() {
        $('.filter-btn').removeClass('active');
        $(this).addClass('active');

        const status = $(this).data('status').toLowerCase();

        // Clear any previous filters before applying a new one
        $.fn.dataTable.ext.search = [];

        if (status === '') {
            // “All” clicked → clear all filters & redraw
            table.search('').columns().search('').draw();
        } else {
            // Apply new status filter (case-insensitive)
            $.fn.dataTable.ext.search.push(function(settings, data) {
                const cellStatus = (data[6] || '').toLowerCase().trim(); // Status column index changed to 6
                return cellStatus.includes(status);
            });
            table.draw();
        }
    });

    // ✅ DATE FILTER
    $('#dateFilter').on('change', function() {
        const date = $(this).val();
        table.column(4).search(date || '', true, false).draw(); // Date column index changed to 4
    });

    $('#clearDateFilter').on('click', function() {
        $('#dateFilter').val('');
        table.column(4).search('').draw(); // Date column index changed to 4
    });

    // ✅ REFRESH BUTTON
    $('#refreshTable').on('click', function() {
        const icon = $(this).find('i');
        icon.addClass('fa-spin');
        setTimeout(() => {
            location.reload();
        }, 800);
    });

    // ✅ EXPORT PLACEHOLDER
    $('#exportBtn').on('click', function() {
        Swal.fire({
            title: 'Export Coming Soon!',
            text: 'Export to Excel, CSV, and PDF will be available soon.',
            icon: 'info',
            confirmButtonText: 'OK'
        });
    });

    // ✅ Bootstrap tooltips
    $('[data-bs-toggle="tooltip"]').tooltip();

});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/tour-app/resources/views/bookings/index.blade.php ENDPATH**/ ?>
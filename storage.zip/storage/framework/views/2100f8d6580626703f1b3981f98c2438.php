<?php $__env->startSection('title', 'Manage Routes'); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h4 class="fw-bold">
            <i class="bi bi-map text-primary me-2"></i> Manage City Routes
        </h4>
        <a href="<?php echo e(route('routes.create')); ?>" class="btn btn-primary">
            <i class="bi bi-plus-circle me-2"></i>Add Route
        </a>
    </div>

    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <i class="bi bi-check-circle me-2"></i><?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="card shadow-sm border-0">
        <div class="card-body">
            <?php if($routes->count() > 0): ?>
                <div class="table-responsive">
                    <table class="table table-striped align-middle">
                        <thead class="table-light">
                            <tr>
                                <th>#</th>
                                <th>From City</th>
                                <th>To City</th>
                                <th>Distance (km)</th>
                                <th>Approx Time</th>
                                <th>Toll Tax (₹)</th>
                                <th>Status</th>
                                <th class="text-center">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $routes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $route): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($index + 1); ?></td>
                                    <td><?php echo e($route->fromCity->name ?? 'N/A'); ?></td>
                                    <td><?php echo e($route->toCity->name ?? 'N/A'); ?></td>
                                    <td><?php echo e(number_format($route->distance_km, 2)); ?></td>
                                    <td><?php echo e($route->approx_time ?? '-'); ?></td>
                                    <td>₹<?php echo e(number_format($route->toll_tax, 2)); ?></td>
                                    <td>
                                        <span class="badge bg-<?php echo e($route->status == 'active' ? 'success' : 'secondary'); ?>">
                                            <?php echo e(ucfirst($route->status)); ?>

                                        </span>
                                    </td>
                                    <td class="text-center">
                                        <a href="<?php echo e(route('routes.edit', $route)); ?>" class="btn btn-sm btn-warning">
                                            <i class="bi bi-pencil-square"></i>
                                        </a>
                                        <form action="<?php echo e(route('routes.destroy', $route)); ?>" method="POST" class="d-inline">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Delete this route?')">
                                                <i class="bi bi-trash"></i>
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <p class="text-muted mb-0">No routes found. Click "Add Route" to create one.</p>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/tour-app/resources/views/routes/index.blade.php ENDPATH**/ ?>
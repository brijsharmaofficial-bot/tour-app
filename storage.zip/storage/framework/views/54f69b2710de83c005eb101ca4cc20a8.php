
<?php $__env->startSection('title', 'All Pages'); ?>

<?php $__env->startSection('content'); ?>
    <h2 class="mb-4">All Pages</h2>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <div class="mb-3 text-end">
        <a href="<?php echo e(route('pages.create')); ?>" class="btn btn-primary">+ Create New Page</a>
    </div>

    <div class="card">
        <div class="card-body table-responsive">
            <table class="table table-bordered table-hover">
                <thead class="table-light">
                    <tr>
                        <th>#</th>
                        <th>Title</th>
                        <th>Slug</th>
                        <th>Status</th>
                        <th>Created</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($page->title); ?></td>
                            <td><?php echo e($page->slug); ?></td>
                            <td><span class="badge bg-<?php echo e($page->status === 'published' ? 'success' : 'secondary'); ?>"><?php echo e(ucfirst($page->status)); ?></span></td>
                            <td><?php echo e($page->created_at->format('d M Y')); ?></td>
                            <td>
                                <!-- <a href="<?php echo e(route('pages.show', $page->id)); ?>" class="btn btn-sm btn-info">View</a> -->
                                <a href="<?php echo e(route('pages.edit', $page->id)); ?>" class="btn btn-sm btn-warning">Edit</a>
                                <form action="<?php echo e(route('pages.destroy', $page->id)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Are you sure to delete this page?');">
                                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                    <button class="btn btn-sm btn-danger">Delete</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="6" class="text-center">No pages found.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/tour-app/resources/views/packages/roundtrip/index.blade.php ENDPATH**/ ?>
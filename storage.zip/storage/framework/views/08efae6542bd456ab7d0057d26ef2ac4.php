<?php $__env->startSection('content'); ?>
<div class="container py-4">
  <h4 class="fw-bold mb-3">Edit Pricing (<?php echo e($package->tripType->name); ?>)</h4>
  <form method="POST" action="<?php echo e(route('package_pricing.update', [$package, $detail])); ?>" class="card p-4 shadow-sm border-0">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <div class="row g-3">
      <div class="col-md-4">
        <label class="form-label">Hours</label>
        <input type="number" name="hours" class="form-control" value="<?php echo e($detail->hours); ?>" required>
      </div>
      <div class="col-md-4">
        <label class="form-label">KMs</label>
        <input type="number" name="kms" class="form-control" value="<?php echo e($detail->kms); ?>" required>
      </div>
      <div class="col-md-4">
        <label class="form-label">Price (₹)</label>
        <input type="number" step="0.01" name="price" class="form-control" value="<?php echo e($detail->price); ?>" required>
      </div>
    </div>
    <div class="mt-4 text-end">
      <button class="btn btn-success me-2">Update</button>
      <a href="<?php echo e(route('package_pricing.index', $package)); ?>" class="btn btn-secondary">Cancel</a>
    </div>
  </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/tour-app/resources/views/package_pricing/edit.blade.php ENDPATH**/ ?>
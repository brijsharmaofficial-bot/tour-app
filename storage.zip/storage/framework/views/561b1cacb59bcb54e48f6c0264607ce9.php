<?php $__env->startSection('title', 'Edit Booking'); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-4">
  <div class="d-flex justify-content-between mb-3">
    <h4 class="fw-bold mb-0">
      <i class="bi bi-pencil-square text-primary me-2"></i> Edit Booking
    </h4>
    <a href="<?php echo e(route('bookings.index')); ?>" class="btn btn-outline-secondary btn-sm">
      <i class="bi bi-arrow-left"></i> Back to List
    </a>
  </div>

  <form id="bookingForm" method="POST" action="<?php echo e(route('bookings.update', $booking->id)); ?>" class="card shadow-sm border-0 p-4">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>

    <div class="row g-3">
      
      <div class="col-md-4">
        <label class="form-label">Customer</label>
        <select name="user_id" class="form-select">
          <option value="">Select User</option>
          <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($u->id); ?>" <?php echo e($booking->user_id == $u->id ? 'selected' : ''); ?>>
              <?php echo e($u->name); ?>

            </option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </div>

      
      <div class="col-md-4 position-relative">
        <label class="form-label">Package</label>
        <input type="text" id="packageSearch" class="form-control"
               value="<?php echo e($booking->package ? ($booking->package->tripType->name ?? '') . ': ' . ($booking->package->fromCity->name ?? '') . ' → ' . ($booking->package->toCity->name ?? 'N/A') : ''); ?>"
               placeholder="Search Package (City or Trip Type)...">
        <input type="hidden" name="package_id" id="package_id" value="<?php echo e($booking->package_id); ?>">
        <ul id="packageResults" class="list-group position-absolute w-100 shadow-sm" style="z-index:1000; display:none;"></ul>
      </div>

      
      <div class="col-md-4">
        <label class="form-label">Vendor</label>
        <select name="vendor_id" id="vendor_id" class="form-select">
          <option value="">Select Vendor</option>
          <?php $__currentLoopData = $vendors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($v->id); ?>" <?php echo e($booking->vendor_id == $v->id ? 'selected' : ''); ?>>
              <?php echo e($v->name); ?>

            </option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </div>

      
      <div class="col-md-4">
        <label class="form-label">Cab</label>
        <select name="cab_id" id="cab_id" class="form-select">
          <?php $__currentLoopData = $cabs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($c->id); ?>" <?php echo e($booking->cab_id == $c->id ? 'selected' : ''); ?>>
              <?php echo e($c->cab_name); ?> (<?php echo e(ucfirst($c->cab_type)); ?>)
            </option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </div>

      
      <div class="col-md-4">
        <label class="form-label">From City</label>
        <select name="from_city_id" id="from_city_id" class="form-select">
          <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($city->id); ?>" <?php echo e($booking->from_city_id == $city->id ? 'selected' : ''); ?>>
              <?php echo e($city->name); ?>

            </option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </div>

      
      <div class="col-md-4">
        <label class="form-label">To City</label>
        <select name="to_city_id" id="to_city_id" class="form-select">
          <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($city->id); ?>" <?php echo e($booking->to_city_id == $city->id ? 'selected' : ''); ?>>
              <?php echo e($city->name); ?>

            </option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </div>

      
      <div class="col-md-4">
        <label class="form-label">Pickup Date</label>
        <input type="date" name="pickup_date" value="<?php echo e($booking->pickup_date); ?>" class="form-control" required>
      </div>
      <div class="col-md-4">
        <label class="form-label">Pickup Time</label>
        <input type="time" name="pickup_time" value="<?php echo e($booking->pickup_time); ?>" class="form-control" required>
      </div>

      
      <div class="col-md-6">
        <label class="form-label">Pickup Address</label>
        <input type="text" name="pickup_address" value="<?php echo e($booking->pickup_address); ?>" class="form-control">
      </div>
      <div class="col-md-6">
        <label class="form-label">Drop Address</label>
        <input type="text" name="drop_address" value="<?php echo e($booking->drop_address); ?>" class="form-control">
      </div>

      
      <div class="col-md-4">
        <label class="form-label">Distance (km)</label>
        <input type="number" step="0.01" name="distance_km" id="distance_km" value="<?php echo e($booking->distance_km); ?>" class="form-control">
      </div>
      <div class="col-md-4">
        <label class="form-label">Fare Without GST</label>
        <input type="number" step="0.01" name="fare_without_gst" id="fare_without_gst" value="<?php echo e($booking->fare_without_gst); ?>" class="form-control">
      </div>
      <div class="col-md-4">
        <label class="form-label">Total Estimated Fare (₹)</label>
        <input type="number" step="0.01" name="total_estimated_fare" id="total_estimated_fare" value="<?php echo e($booking->total_estimated_fare); ?>" class="form-control">
      </div>

      
      <div class="col-md-4">
        <label class="form-label">Status</label>
        <select name="status" class="form-select">
          <?php $__currentLoopData = ['pending','assigned','in_progress','completed','cancelled']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $st): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($st); ?>" <?php echo e($booking->status == $st ? 'selected' : ''); ?>>
              <?php echo e(ucfirst($st)); ?>

            </option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </div>

      
      <div class="col-md-4">
        <label class="form-label">Payment Status</label>
        <select name="payment_status" class="form-select">
          <option value="unpaid" <?php echo e($booking->payment_status == 'unpaid' ? 'selected' : ''); ?>>Unpaid</option>
          <option value="paid" <?php echo e($booking->payment_status == 'paid' ? 'selected' : ''); ?>>Paid</option>
        </select>
      </div>
    </div>

    <div class="mt-4 text-end">
      <button class="btn btn-primary"><i class="bi bi-check-circle"></i> Update</button>
      <a href="<?php echo e(route('bookings.index')); ?>" class="btn btn-secondary">Cancel</a>
    </div>
  </form>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', function () {
  const vendorSelect = document.getElementById('vendor_id');
  const cabSelect = document.getElementById('cab_id');
  const pkgSearch = document.getElementById('packageSearch');
  const pkgResults = document.getElementById('packageResults');
  const pkgHidden = document.getElementById('package_id');

  // 🔍 Autocomplete search for packages
  pkgSearch.addEventListener('input', async () => {
    const q = pkgSearch.value.trim();
    pkgResults.innerHTML = '';
    pkgResults.style.display = 'none';
    if (q.length < 2) return;

    const res = await fetch(`/admin/packages/search?q=${q}`);
    const data = await res.json();

    if (data.length) {
      pkgResults.innerHTML = data.map(p => `
        <li class="list-group-item list-group-item-action"
            data-id="${p.id}">
          ${p.trip_type_name} — ${p.from_city_name} → ${p.to_city_name || 'N/A'}
        </li>`).join('');
      pkgResults.style.display = 'block';
    }
  });

  pkgResults.addEventListener('click', e => {
    if (e.target.matches('li')) {
      pkgSearch.value = e.target.textContent.trim();
      pkgHidden.value = e.target.dataset.id;
      pkgResults.style.display = 'none';
    }
  });

  // 💡 Load vendor-wise cabs dynamically
  vendorSelect.addEventListener('change', async () => {
    const id = vendorSelect.value;
    cabSelect.innerHTML = '<option>Loading...</option>';
    if (!id) return;
    const res = await fetch(`/admin/get-cabs?vendor_id=${id}`);
    const data = await res.json();
    cabSelect.innerHTML = data.length
      ? data.map(c => `<option value="${c.id}">${c.cab_name} (${c.cab_type})</option>`).join('')
      : '<option>No cabs available</option>';
  });
});
</script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('styles'); ?>
<style>
#packageResults li:hover { background:#f8f9fa; cursor:pointer; }
</style>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/tour-app/resources/views/bookings/edit.blade.php ENDPATH**/ ?>